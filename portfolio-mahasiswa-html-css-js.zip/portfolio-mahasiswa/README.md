# Portofolio Mahasiswa — HTML, CSS, JavaScript

Template website portofolio statis dengan tema gelap, aksen hijau mint, tipografi modern, navigasi responsif, bagian profil, keahlian, proyek, perjalanan, dan kontak.

## Struktur folder

```text
portfolio-mahasiswa/
├── index.html
├── style.css
├── script.js
└── README.md
```

## Cara menjalankan

1. Ekstrak ZIP ke folder pilihan.
2. Buka folder `portfolio-mahasiswa`.
3. Klik dua kali `index.html` untuk membukanya di browser.
4. Untuk pengalaman pengembangan yang lebih nyaman, buka folder di Visual Studio Code lalu jalankan `index.html` menggunakan ekstensi Live Server.

Website ini tidak memerlukan instalasi paket atau server backend.

## Bagian yang harus kamu ubah

Cari dan ganti teks contoh di `index.html`:
- `Nama Mahasiswa`
- deskripsi profil dan lokasi
- nama universitas, program studi, serta riwayat pendidikan
- keterampilan yang benar-benar kamu kuasai
- judul, deskripsi, tahun, dan teknologi proyek
- `emailkamu@example.com`
- tautan LinkedIn dan GitHub dengan akun milikmu

Bagian proyek saat ini adalah contoh desain, bukan klaim bahwa proyek tersebut sudah kamu kerjakan. Sesuaikan dengan pengalaman asli.

## Kustomisasi warna

Di awal `style.css`, ubah variabel pada `:root`, terutama:
- `--bg`: warna latar utama
- `--panel`: warna kartu
- `--text`: warna teks
- `--green`: warna aksen utama

## Catatan

- Google Fonts membutuhkan koneksi internet. Jika tidak ada koneksi, browser memakai font cadangan.
- Form kontak belum digunakan; tautan email, LinkedIn, dan GitHub adalah tautan langsung.
- Ini merupakan website frontend statis. Fitur seperti login, database, atau formulir yang mengirim data memerlukan backend atau layanan tambahan.
